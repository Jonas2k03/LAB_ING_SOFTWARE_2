package parcialsoftwareii;

/**
 *
 * @author Juan Carlos Fernandez Cuetia
 * @author Jonathan Felipe Hurtado Diaz
 * @author Juan Esteban Yepez
 */
public interface IAutenticar {

    boolean Autenticar();
}
