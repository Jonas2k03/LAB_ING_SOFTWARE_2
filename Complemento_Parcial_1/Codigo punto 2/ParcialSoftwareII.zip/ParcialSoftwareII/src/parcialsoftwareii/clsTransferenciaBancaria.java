package parcialsoftwareii;

/**
 *
 * @author Juan Carlos Fernandez Cuetia
 * @author Jonathan Felipe Hurtado Diaz
 * @author Juan Esteban Yepez
 */
public class clsTransferenciaBancaria implements ILlenarInfo, IPago {

    private int numCuenta;
    private String password;

    public clsTransferenciaBancaria() {
    }

    public clsTransferenciaBancaria(int numCuenta, String password) {
        this.numCuenta = numCuenta;
        this.password = password;
    }

    @Override
    public void llenarInfo() {
        //Se llena la inforamcion De la cuenta Bancaria
    }

    /**
     *
     * @return
     */
    @Override
    public boolean realizarPago() {
        //Se Realiza el pago
        System.out.println("Se ha realizado un pago con Transferencia Bancaria");
        //retorna true si se hizo el pago de lo contrario retorna false
        return true;
    }
    
        public int getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
