package parcialsoftwareii;



/**
 *
 * @author Juan Carlos Fernandez Cuetia
 * @author Jonathan Felipe Hurtado Diaz
 * @author Juan Esteban Yepez
 */
public class clsPago implements IPago {


    public clsPago(IPago pago) {
    }

    public void procesarPago() {
        realizarPago();
    }

    @Override
    public boolean realizarPago() {
        System.out.println("Procesando pago");
        return false;
    }
}
