package parcialsoftwareii;

/**
 *
 * @author Juan Carlos Fernandez Cuetia
 * @author Jonathan Felipe Hurtado Diaz
 * @author Juan Esteban Yepez
 */
public class clsMain {

    public static void main(String[] args) {
        /*
        //PAGAR CON PAYPAL
        clsPaypal paypal = new clsPaypal("pepe", "123");
        paypal.realizarPago();
        */
        
        /*
        //PAGAR CON TARJETA
        clsTarjetaCredito objTarjeta = new clsTarjetaCredito();
        objTarjeta.realizarPago();
        */
        
        /*
        //PAGAR CON TRANSFERENCIA BANCARIA
        clsTransferenciaBancaria objTfBancaria = new clsTransferenciaBancaria(912903120, "pepe123");
        objTfBancaria.realizarPago();
        */
        
        
    }

}
