package parcialsoftwareii;

import static java.lang.reflect.Array.get;
import java.util.Date;

/**
 *
 * @author Juan Carlos Fernandez Cuetia
 * @author Jonathan Felipe Hurtado Diaz
 * @author Juan Esteban Yepez
 */
public class clsTarjetaCredito implements ILlenarInfo, IPago, IAutenticar {

    String nombreTitular;
    int numTarjetaCredito;
    Date fechaVencimiento;
    int codigoSeguridad;

    public clsTarjetaCredito() {
    }

    public clsTarjetaCredito(String nombreTitular, int numTargetaCredito, Date fechaVencimiento, int codigoSeguridad) {
        this.nombreTitular = nombreTitular;
        this.numTarjetaCredito = numTargetaCredito;
        this.fechaVencimiento = fechaVencimiento;
        this.codigoSeguridad = codigoSeguridad;
    }

 

    public void llenarInfo() {
        //Se llena toda la informacion correspondiente a la tarjeta de credito
    }

    public boolean Autenticar() {
        //Se verifica el limite, si cumple con el limite retorna true si no, returna false
        return true;
    }

    public boolean realizarPago() {
        System.out.println("Se ha realizado un pago con Tarjeta de Credito");
        //retorna true si se realizo el pago de lo contrario retorna false
        return true;
    }
    
       public String NombreTitular() {
        return nombreTitular;
    }

    public int NumTarjetaCredito() {
        return numTarjetaCredito;

    }

    public Date FechaVencimiento() {
        return fechaVencimiento;
    }

    public int CodigoSeguridad() {
        return codigoSeguridad;
    }
}
