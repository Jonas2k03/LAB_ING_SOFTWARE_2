package parcialsoftwareii;

/**
 *
 * @author Juan Carlos Fernandez Cuetia
 * @author Jonathan Felipe Hurtado Diaz
 * @author Juan Esteban Yepez
 */
public class clsPaypal implements IPago {

    String user;
    String password;

    public clsPaypal() {
    }

    public clsPaypal(String user, String password) {
        this.user = user;
        this.password = password;
    }


    public boolean Autenticar() {
        //Verifica Las credenciales de la cuenta paypal, si son correctas returna true de lo contrario false
        return true;
    }

    /**
     *
     * @return
     */
    @Override
    public boolean realizarPago() {
        System.out.println("Se ha realizado un pago con Paypal");
        //retorna true si se hizo el pago de lo contrario retorna false 
        return true;
    }
    
     public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
