/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Juan Carlos Fernandez Cuetia (jcfernandezc@unicauca.edu.co)
 * @author Jonathan Felipe Hurtado Diaz (jfhurtadod@unicauca.edu.co)
 * @author Juan Esteban Yepez Rodriguez (jyepezr@unicauca.edu.co)
 */

public class SMS {

    private int telefono;


    public SMS() {

    }

    public String enviarSMS(Accion accion) { //Retorna un mensaje que se mostrará en la vista
        
        
        if (accion.getPrecioActual() > accion.getUmbralSuperior()) {
            return "El precio actual de la accion " + accion.getNombreAccion()  + " ha superado el umbral superior.";
        }

        if (accion.getPrecioActual() < accion.getUmbralInferior()) {
            return "El precio actual de la accion " + accion.getNombreAccion() + " ha superado el umbral inferior.";
        }

        return "La accion " + accion.getNombreAccion() + " se mantiene dentro de los umbrales";

    }


    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

}
