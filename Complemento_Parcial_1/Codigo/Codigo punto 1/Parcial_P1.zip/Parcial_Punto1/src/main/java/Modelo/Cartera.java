/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Juan Carlos Fernandez Cuetia (jcfernandezc@unicauca.edu.co)
 * @author Jonathan Felipe Hurtado Diaz (jfhurtadod@unicauca.edu.co)
 * @author Juan Esteban Yepez Rodriguez (jyepezr@unicauca.edu.co)
 */

public class Cartera {

    private List<Accion> acciones;

    public Cartera() {
        acciones = new ArrayList<>(); //Lista de acciones 
    }

    public void agregarAccion(Accion a) { //Agrega una accion especifica a una lista
        acciones.add(a);
    }

    public boolean eliminarAccion(String nombreAccion) throws Exception { //Elimina una accion determinada de la lista.
        Accion accion = buscarAccionPorNombre(nombreAccion);
        if (accion != null) {
            acciones.remove(accion);
            return true;
        }
        return false;
    }


    public Accion buscarAccionPorNombre(String nombre) { //Busca una determinada accion dentro de la lista
        for (Accion accion : acciones) {
            if (accion.getNombreAccion().equals(nombre)) {
                return accion; 
            }
        }

      
        return null;
    }

    public List<Accion> getAcciones() {
        return acciones;
    }

    public void setAcciones(List<Accion> acciones) {
        this.acciones = acciones;
    }

}
