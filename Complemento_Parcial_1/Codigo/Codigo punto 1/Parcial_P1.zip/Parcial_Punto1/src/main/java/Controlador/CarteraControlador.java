/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Accion;
import Modelo.Cartera;
import java.util.List;

/**
 *
 * @author Juan Carlos Fernandez Cuetia (jcfernandezc@unicauca.edu.co)
 * @author Jonathan Felipe Hurtado Diaz (jfhurtadod@unicauca.edu.co)
 * @author Juan Esteban Yepez Rodriguez (jyepezr@unicauca.edu.co)
 */

public class CarteraControlador {
    private final Cartera cartera;

    public CarteraControlador(Cartera cartera) {
        this.cartera = cartera;
    }
    
     public void agregarAccion(String nombre, String estado, int precioActual, int precioAnterior, int umbralInferior, int umbralSuperior, boolean cambioEstado) throws Exception {
        Accion nuevaAccion = new Accion(nombre, estado, precioActual, precioAnterior, umbralInferior, umbralSuperior, cambioEstado);
        cartera.agregarAccion(nuevaAccion);
    }
     
     
     public boolean removerAccion(String nombreAccion) throws Exception {
         return cartera.eliminarAccion(nombreAccion);
     }
     
     public List<Accion> getAcciones() {
        return cartera.getAcciones();
    }
    
    
}
