/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Juan Carlos Fernandez Cuetia (jcfernandezc@unicauca.edu.co)
 * @author Jonathan Felipe Hurtado Diaz (jfhurtadod@unicauca.edu.co)
 * @author Juan Esteban Yepez Rodriguez (jyepezr@unicauca.edu.co)
 */
public class Accion implements iObservado {

    private String nombreAccion;
    private int precioActual;
    private int precioAnterior;
    private int umbralInferior;
    private int umbralSuperior;
    private boolean avisar;

    //Lista de observadores
    private List<iObservador> Observadores = new ArrayList<>(); //Lista de observadores para esta clase

    public Accion(String nombreAccion, String estado, int precioActual, int precioAnterior, int umbralInferior, int umbralSuperior, boolean cambioEstado) {
        this.nombreAccion = nombreAccion;
        this.precioActual = precioActual;
        this.precioAnterior = precioAnterior;
        this.umbralInferior = umbralInferior;
        this.umbralSuperior = umbralSuperior;
        this.avisar = cambioEstado;
    }

    public Accion() {

    }

    @Override
    public void asociarObservador(iObservador o) {//Agrega un observador a la lista
        if (Observadores.isEmpty()) {
            Observadores = new ArrayList<>();
        }
        Observadores.add(o);
    }

    @Override
    public void retirarObservador(iObservador o) { //Retira un observador de la lista
        if (!Observadores.isEmpty()) {
            Observadores.remove(o);
        }
    }
    
     @Override
    public boolean existeObservador(iObservador prmOb) { //Determina si un observdor ya existe en la lista de observadores para esta clase
        for (iObservador o : Observadores) {
                if(o==prmOb) 
                    return true;
            } 
        return false;
    }

    @Override
    public void notificar(boolean cambioEstado) { //Notifica a todos los observadores asociados.
        if (cambioEstado == true) {
            for (iObservador o : Observadores) {
                o.actualizar();
            }
        }

    }

    public String getNombreAccion() {
        return nombreAccion;
    }

    public void setNombreAccion(String nombreAccion) {
        this.nombreAccion = nombreAccion;
    }


    public int getPrecioActual() {
        return precioActual;
    }

    public void setPrecioActual(int precioActual) {
        this.precioActual = precioActual;
    }

    public int getPrecioAnterior() {
        return precioAnterior;
    }

    public void setPrecioAnterior(int precioAnterior) {
        this.precioAnterior = precioAnterior;
    }

    public int getUmbralInferior() {
        return umbralInferior;
    }

    public void setUmbralInferior(int umbralInferior) {
        this.umbralInferior = umbralInferior;
    }

    public int getUmbralSuperior() {
        return umbralSuperior;
    }

    public void setUmbralSuperior(int umbralSuperior) {
        this.umbralSuperior = umbralSuperior;
    }

    public boolean isAvisar() {
        return avisar;
    }

    public void setAvisar(boolean avisar) {
        this.avisar = avisar;
    }

    public List<iObservador> getObservadores() {
        return Observadores;
    }

    public void setObservadores(List<iObservador> Observadores) {
        this.Observadores = Observadores;
    }

   

}
