/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Accion;
import Modelo.SMS;

/**
 *
 * @author Juan Carlos Fernandez Cuetia (jcfernandezc@unicauca.edu.co)
 * @author Jonathan Felipe Hurtado Diaz (jfhurtadod@unicauca.edu.co)
 * @author Juan Esteban Yepez Rodriguez (jyepezr@unicauca.edu.co)
 */

public class SMSControlador {
    private final SMS objSMS;

    public SMSControlador(SMS objSMS) {
        this.objSMS = objSMS;
    }
    
    public String enviarSMS(Accion accion) {
        return objSMS.enviarSMS(accion);
    }
}
