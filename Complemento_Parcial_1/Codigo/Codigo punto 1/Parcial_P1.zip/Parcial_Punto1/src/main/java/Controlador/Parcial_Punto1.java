/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Controlador;

import Modelo.Accion;
import Modelo.Cartera;
import Modelo.SMS;
import Vista.AccionesUI;
import Vista.GestionarAccionUI;
import Vista.VerAccionesUI;

/**
 *
 * @author Juan Carlos Fernandez Cuetia (jcfernandezc@unicauca.edu.co)
 * @author Jonathan Felipe Hurtado Diaz (jfhurtadod@unicauca.edu.co)
 * @author Juan Esteban Yepez Rodriguez (jyepezr@unicauca.edu.co)
 */

public class Parcial_Punto1 {

    public static void main(String[] args) {
        Cartera cartera = new Cartera();
        CarteraControlador carteraControlador = new CarteraControlador(cartera);
        
        Accion accion = new Accion();
        AccionControlador accionControlador = new AccionControlador(accion);
        
        SMS objSMS  = new SMS();
        SMSControlador smsControlador = new SMSControlador(objSMS);
        
        VerAccionesUI verAccionesUI = new VerAccionesUI(carteraControlador, accionControlador, smsControlador);
        GestionarAccionUI agregarAccionUI = new GestionarAccionUI(carteraControlador, accionControlador, verAccionesUI, smsControlador);
        
        
        AccionesUI objAccionesUI = new AccionesUI(carteraControlador, accionControlador, verAccionesUI, smsControlador);
        objAccionesUI.setVisible(true);
        
    }
}
